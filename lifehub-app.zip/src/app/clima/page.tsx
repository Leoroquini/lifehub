'use client';

import { climaData } from '@/data/mockData';

export default function Clima() {
  // Função para obter ícone baseado na condição climática
  const getIconeClima = (condicao: string) => {
    switch (condicao) {
      case 'parcialmente nublado':
        return 'partly_cloudy_day';
      case 'ensolarado':
        return 'wb_sunny';
      case 'chuvoso':
        return 'rainy';
      default:
        return 'cloud';
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Previsão do Tempo</h1>
        
        {/* Clima atual */}
        <div className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row md:items-center">
            <div className="flex-1">
              <h2 className="text-xl font-semibold mb-2">Clima Atual</h2>
              <div className="flex items-center">
                <span className="text-5xl font-bold">{climaData.atual.temperatura}°C</span>
                <div className="ml-4">
                  <p className="capitalize text-lg">{climaData.atual.condicao}</p>
                  <p className="text-blue-100">Sensação térmica: {climaData.atual.sensacao}°C</p>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2">
                <div>
                  <p className="text-blue-100">Umidade</p>
                  <p className="font-medium">{climaData.atual.umidade}%</p>
                </div>
                <div>
                  <p className="text-blue-100">Vento</p>
                  <p className="font-medium">{climaData.atual.vento} km/h</p>
                </div>
              </div>
            </div>
            <div className="mt-6 md:mt-0 flex justify-center">
              <div className="h-24 w-24 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                <span className="material-symbols-outlined text-5xl">
                  {getIconeClima(climaData.atual.condicao)}
                </span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Mensagem contextual */}
        <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-md mb-6">
          <p className="text-blue-700">
            <span className="material-symbols-outlined align-middle mr-2">tips_and_updates</span>
            {climaData.mensagem}
          </p>
        </div>
        
        {/* Previsão da semana */}
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Previsão da Semana</h2>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {climaData.previsao.map((dia, index) => (
            <div 
              key={index} 
              className="border border-gray-200 rounded-lg p-4 text-center hover:shadow-md transition-shadow"
            >
              <p className="font-medium text-gray-900">{dia.dia}</p>
              <p className="text-sm text-gray-500">{dia.data}</p>
              <div className="my-3 flex justify-center">
                <span className="material-symbols-outlined text-3xl text-blue-500">
                  {getIconeClima(dia.condicao)}
                </span>
              </div>
              <div className="flex justify-center items-center space-x-2">
                <span className="text-red-500 font-medium">{dia.maxima}°</span>
                <span className="text-gray-300">|</span>
                <span className="text-blue-500 font-medium">{dia.minima}°</span>
              </div>
              <div className="mt-2 text-sm">
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                  <span className="material-symbols-outlined text-xs mr-1">water_drop</span>
                  {dia.probabilidadeChuva}%
                </span>
              </div>
            </div>
          ))}
        </div>
        
        {/* Informações adicionais */}
        <div className="mt-8 bg-gray-50 rounded-lg p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Recomendações Baseadas no Clima</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start">
              <div className="flex-shrink-0 h-10 w-10 rounded-md bg-green-100 flex items-center justify-center mr-3">
                <span className="material-symbols-outlined text-green-600">directions_walk</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Atividades ao Ar Livre</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Manhã ideal para caminhadas ou exercícios ao ar livre. Considere atividades internas à tarde devido à possibilidade de chuva.
                </p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0 h-10 w-10 rounded-md bg-blue-100 flex items-center justify-center mr-3">
                <span className="material-symbols-outlined text-blue-600">umbrella</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">O que Levar</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Recomendamos levar um guarda-chuva ou capa de chuva para a tarde. Roupas leves são adequadas para a temperatura atual.
                </p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0 h-10 w-10 rounded-md bg-amber-100 flex items-center justify-center mr-3">
                <span className="material-symbols-outlined text-amber-600">wb_twilight</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Índice UV</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Índice UV moderado pela manhã. Use protetor solar se planeja ficar exposto ao sol por períodos prolongados.
                </p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="flex-shrink-0 h-10 w-10 rounded-md bg-purple-100 flex items-center justify-center mr-3">
                <span className="material-symbols-outlined text-purple-600">air</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Qualidade do Ar</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Qualidade do ar boa. Ideal para atividades ao ar livre, especialmente nas primeiras horas do dia.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
