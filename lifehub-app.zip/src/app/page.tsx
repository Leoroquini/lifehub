'use client';

import Link from 'next/link';

export default function Page() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] text-center px-4">
      <h1 className="text-4xl font-bold text-indigo-600 mb-6">LifeHub</h1>
      <p className="text-xl text-gray-600 mb-8">Um super app que centraliza sua vida com inteligência artificial</p>
      <Link 
        href="/dashboard" 
        className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 px-6 rounded-md transition duration-150 ease-in-out text-lg"
      >
        Começar
      </Link>
    </div>
  );
}
