'use client';

import { useState } from 'react';
import { tarefasData } from '@/data/mockData';

export default function Tarefas() {
  const [tarefas, setTarefas] = useState(tarefasData);
  const [novaTarefa, setNovaTarefa] = useState('');
  const [filtro, setFiltro] = useState('todas');

  const handleToggleTarefa = (id: number) => {
    setTarefas(tarefas.map(tarefa => 
      tarefa.id === id ? { ...tarefa, concluida: !tarefa.concluida } : tarefa
    ));
  };

  const handleAddTarefa = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!novaTarefa.trim()) return;
    
    // Simulação de processamento de linguagem natural
    let prioridade = 'média';
    let categoria = 'pessoal';
    let horario = '12:00';
    
    if (novaTarefa.includes('#alta')) {
      prioridade = 'alta';
    } else if (novaTarefa.includes('#baixa')) {
      prioridade = 'baixa';
    }
    
    if (novaTarefa.toLowerCase().includes('trabalho') || novaTarefa.includes('#trabalho')) {
      categoria = 'trabalho';
    } else if (novaTarefa.toLowerCase().includes('saúde') || novaTarefa.includes('#saúde')) {
      categoria = 'saúde';
    }
    
    // Extração de horário (formato: até XXh ou às XXh ou XXh)
    const horarioMatch = novaTarefa.match(/(?:até|às)\s*(\d{1,2})[h:]\s*(\d{0,2})|(\d{1,2})[h:]\s*(\d{0,2})/i);
    if (horarioMatch) {
      const horas = horarioMatch[1] || horarioMatch[3];
      const minutos = horarioMatch[2] || horarioMatch[4] || '00';
      horario = `${horas}:${minutos.padEnd(2, '0')}`;
    }
    
    // Remover tags da descrição
    let titulo = novaTarefa
      .replace(/#alta|#média|#baixa|#trabalho|#pessoal|#saúde/g, '')
      .replace(/até \d{1,2}[h:]\d{0,2}|às \d{1,2}[h:]\d{0,2}|\d{1,2}[h:]\d{0,2}/g, '')
      .trim();
    
    const novaTarefaObj = {
      id: tarefas.length + 1,
      titulo,
      prioridade,
      concluida: false,
      horario,
      categoria
    };
    
    setTarefas([...tarefas, novaTarefaObj]);
    setNovaTarefa('');
  };

  const tarefasFiltradas = filtro === 'todas' 
    ? tarefas 
    : filtro === 'concluidas' 
      ? tarefas.filter(tarefa => tarefa.concluida) 
      : tarefas.filter(tarefa => !tarefa.concluida);

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Tarefas do Dia</h1>
        
        {/* Formulário para adicionar tarefa */}
        <form onSubmit={handleAddTarefa} className="mb-6">
          <div className="flex">
            <input
              type="text"
              value={novaTarefa}
              onChange={(e) => setNovaTarefa(e.target.value)}
              placeholder="Adicionar tarefa com linguagem natural (ex: Revisar trabalho até 16h #alta)"
              className="flex-grow px-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
            <button
              type="submit"
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-r-md transition duration-150 ease-in-out"
            >
              Adicionar
            </button>
          </div>
          <p className="mt-2 text-sm text-gray-500">
            Use #alta, #média, #baixa para prioridade e especifique horário (ex: até 15h)
          </p>
        </form>
        
        {/* Filtros */}
        <div className="flex space-x-2 mb-4">
          <button
            onClick={() => setFiltro('todas')}
            className={`px-3 py-1 rounded-md text-sm font-medium ${
              filtro === 'todas' 
                ? 'bg-indigo-100 text-indigo-800' 
                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
            }`}
          >
            Todas
          </button>
          <button
            onClick={() => setFiltro('pendentes')}
            className={`px-3 py-1 rounded-md text-sm font-medium ${
              filtro === 'pendentes' 
                ? 'bg-indigo-100 text-indigo-800' 
                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
            }`}
          >
            Pendentes
          </button>
          <button
            onClick={() => setFiltro('concluidas')}
            className={`px-3 py-1 rounded-md text-sm font-medium ${
              filtro === 'concluidas' 
                ? 'bg-indigo-100 text-indigo-800' 
                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
            }`}
          >
            Concluídas
          </button>
        </div>
        
        {/* Lista de tarefas */}
        <div className="space-y-3">
          {tarefasFiltradas.length > 0 ? (
            tarefasFiltradas.map((tarefa) => (
              <div 
                key={tarefa.id} 
                className={`flex items-center p-4 border rounded-md ${
                  tarefa.concluida ? 'bg-gray-50 border-gray-200' : 'bg-white border-gray-300'
                }`}
              >
                <input
                  type="checkbox"
                  checked={tarefa.concluida}
                  onChange={() => handleToggleTarefa(tarefa.id)}
                  className="h-5 w-5 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                />
                <div className="ml-3 flex-grow">
                  <p className={`text-gray-900 ${tarefa.concluida ? 'line-through text-gray-500' : 'font-medium'}`}>
                    {tarefa.titulo}
                  </p>
                  <div className="flex items-center mt-1">
                    <span className="text-sm text-gray-500 mr-3">
                      <span className="material-symbols-outlined text-sm align-middle mr-1">schedule</span>
                      {tarefa.horario}
                    </span>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      tarefa.prioridade === 'alta' 
                        ? 'bg-red-100 text-red-800' 
                        : tarefa.prioridade === 'média'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-green-100 text-green-800'
                    }`}>
                      {tarefa.prioridade}
                    </span>
                    <span className="inline-flex items-center ml-2 px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 capitalize">
                      {tarefa.categoria}
                    </span>
                  </div>
                </div>
                <button className="ml-2 text-gray-400 hover:text-gray-500">
                  <span className="material-symbols-outlined">more_vert</span>
                </button>
              </div>
            ))
          ) : (
            <p className="text-gray-500 text-center py-4">Nenhuma tarefa encontrada.</p>
          )}
        </div>
      </div>
    </div>
  );
}
