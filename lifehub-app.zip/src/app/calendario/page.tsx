'use client';

import { useState } from 'react';
import { eventosData } from '@/data/mockData';

export default function Calendario() {
  const [visualizacao, setVisualizacao] = useState('dia');
  const [diaAtual, setDiaAtual] = useState('2025-05-19');
  const [mostrarNovoEvento, setMostrarNovoEvento] = useState(false);
  
  // Filtrar eventos do dia atual
  const eventosDoDia = eventosData.filter(evento => evento.data === diaAtual);
  
  // Obter dias da semana atual para visualização semanal
  const diasDaSemana = ['2025-05-19', '2025-05-20', '2025-05-21', '2025-05-22', '2025-05-23'];
  const nomesDosDias = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta'];
  
  // Função para formatar a data
  const formatarData = (dataString: string) => {
    const [ano, mes, dia] = dataString.split('-');
    return `${dia}/${mes}`;
  };
  
  // Função para obter cor baseada no tipo de evento
  const getCorEvento = (tipo: string) => {
    switch (tipo) {
      case 'trabalho':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'pessoal':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'saúde':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Calendário</h1>
          <div className="flex space-x-2">
            <button
              onClick={() => setVisualizacao('dia')}
              className={`px-3 py-1 rounded-md text-sm font-medium ${
                visualizacao === 'dia' 
                  ? 'bg-indigo-100 text-indigo-800' 
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
            >
              Dia
            </button>
            <button
              onClick={() => setVisualizacao('semana')}
              className={`px-3 py-1 rounded-md text-sm font-medium ${
                visualizacao === 'semana' 
                  ? 'bg-indigo-100 text-indigo-800' 
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
            >
              Semana
            </button>
          </div>
        </div>
        
        {/* Navegação de data */}
        <div className="flex justify-between items-center mb-6">
          <button className="p-1 rounded-full hover:bg-gray-100">
            <span className="material-symbols-outlined">chevron_left</span>
          </button>
          <h2 className="text-lg font-medium text-gray-900">
            {visualizacao === 'dia' 
              ? `Segunda-feira, ${formatarData(diaAtual)}` 
              : `Semana de ${formatarData(diasDaSemana[0])} a ${formatarData(diasDaSemana[4])}`}
          </h2>
          <button className="p-1 rounded-full hover:bg-gray-100">
            <span className="material-symbols-outlined">chevron_right</span>
          </button>
        </div>
        
        {/* Visualização do dia */}
        {visualizacao === 'dia' && (
          <div className="space-y-4">
            {eventosDoDia.length > 0 ? (
              eventosDoDia.map((evento) => (
                <div 
                  key={evento.id} 
                  className={`p-4 border rounded-md ${getCorEvento(evento.tipo)}`}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium">{evento.titulo}</h3>
                      <p className="text-sm mt-1">
                        {evento.inicio} - {evento.fim}
                      </p>
                      {evento.local && (
                        <p className="text-sm mt-1">
                          <span className="material-symbols-outlined text-sm align-middle mr-1">location_on</span>
                          {evento.local}
                        </p>
                      )}
                    </div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-white bg-opacity-50 capitalize">
                      {evento.tipo}
                    </span>
                  </div>
                  {evento.participantes.length > 0 && (
                    <div className="mt-3">
                      <p className="text-xs text-gray-600 mb-1">Participantes:</p>
                      <div className="flex flex-wrap gap-1">
                        {evento.participantes.map((participante, index) => (
                          <span 
                            key={index}
                            className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-white bg-opacity-50"
                          >
                            {participante}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center py-8">Nenhum evento agendado para este dia.</p>
            )}
          </div>
        )}
        
        {/* Visualização da semana */}
        {visualizacao === 'semana' && (
          <div className="grid grid-cols-5 gap-4">
            {diasDaSemana.map((dia, index) => {
              const eventosDoDia = eventosData.filter(evento => evento.data === dia);
              return (
                <div key={dia} className="border rounded-md overflow-hidden">
                  <div className="bg-gray-50 p-2 text-center border-b">
                    <p className="font-medium">{nomesDosDias[index]}</p>
                    <p className="text-sm text-gray-500">{formatarData(dia)}</p>
                  </div>
                  <div className="p-2 h-64 overflow-y-auto">
                    {eventosDoDia.length > 0 ? (
                      eventosDoDia.map((evento) => (
                        <div 
                          key={evento.id} 
                          className={`p-2 mb-2 text-sm rounded ${getCorEvento(evento.tipo)}`}
                        >
                          <p className="font-medium truncate">{evento.titulo}</p>
                          <p className="text-xs mt-1">{evento.inicio} - {evento.fim}</p>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs text-gray-500 text-center py-4">Sem eventos</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
        
        {/* Botão para adicionar evento */}
        <div className="mt-6 flex justify-center">
          <button
            onClick={() => setMostrarNovoEvento(!mostrarNovoEvento)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <span className="material-symbols-outlined mr-1">add</span>
            Novo Evento
          </button>
        </div>
        
        {/* Formulário de novo evento (simulado) */}
        {mostrarNovoEvento && (
          <div className="mt-6 p-4 border border-gray-200 rounded-md bg-gray-50">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">Novo Evento</h3>
              <button 
                onClick={() => setMostrarNovoEvento(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="titulo" className="block text-sm font-medium text-gray-700">Título</label>
                <input
                  type="text"
                  id="titulo"
                  className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Título do evento"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="data" className="block text-sm font-medium text-gray-700">Data</label>
                  <input
                    type="date"
                    id="data"
                    defaultValue={diaAtual}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
                <div>
                  <label htmlFor="tipo" className="block text-sm font-medium text-gray-700">Tipo</label>
                  <select
                    id="tipo"
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  >
                    <option value="trabalho">Trabalho</option>
                    <option value="pessoal">Pessoal</option>
                    <option value="saúde">Saúde</option>
                  </select>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="inicio" className="block text-sm font-medium text-gray-700">Hora de início</label>
                  <input
                    type="time"
                    id="inicio"
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
                <div>
                  <label htmlFor="fim" className="block text-sm font-medium text-gray-700">Hora de término</label>
                  <input
                    type="time"
                    id="fim"
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="local" className="block text-sm font-medium text-gray-700">Local</label>
                <input
                  type="text"
                  id="local"
                  className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                  placeholder="Local do evento (opcional)"
                />
              </div>
              
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => setMostrarNovoEvento(false)}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  Salvar Evento
                </button>
              </div>
              
              <div className="bg-blue-50 p-3 rounded-md">
                <p className="text-sm text-blue-700 flex items-start">
                  <span className="material-symbols-outlined mr-2 flex-shrink-0">smart_toy</span>
                  <span>
                    <strong>Sugestão da IA:</strong> Com base na sua agenda, o melhor horário para este evento seria às 11:00, entre a reunião de planejamento e o almoço com cliente.
                  </span>
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
