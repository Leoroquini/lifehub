'use client';

import { useState } from 'react';
import { lembretesData } from '@/data/mockData';

export default function Lembretes() {
  const [lembretes, setLembretes] = useState(lembretesData);
  const [filtroTipo, setFiltroTipo] = useState('todos');
  const [mostrarSimulacao, setMostrarSimulacao] = useState(false);
  
  // Função para marcar lembrete como lido
  const marcarComoLido = (id: number) => {
    setLembretes(lembretes.map(lembrete => 
      lembrete.id === id ? { ...lembrete, lido: true } : lembrete
    ));
  };
  
  // Filtrar lembretes por tipo
  const lembretesFiltrados = filtroTipo === 'todos' 
    ? lembretes 
    : lembretes.filter(lembrete => lembrete.tipo === filtroTipo);
  
  // Obter cor baseada no tipo de lembrete
  const getCorLembrete = (tipo: string) => {
    switch (tipo) {
      case 'clima':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'trabalho':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'transporte':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'pessoal':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'dispositivo':
        return 'bg-gray-100 text-gray-800 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };
  
  // Obter ícone baseado no tipo de lembrete
  const getIconeLembrete = (tipo: string) => {
    switch (tipo) {
      case 'clima':
        return 'cloud';
      case 'trabalho':
        return 'work';
      case 'transporte':
        return 'directions_car';
      case 'pessoal':
        return 'person';
      case 'dispositivo':
        return 'smartphone';
      default:
        return 'notifications';
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Lembretes Inteligentes</h1>
          <button
            onClick={() => setMostrarSimulacao(!mostrarSimulacao)}
            className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            {mostrarSimulacao ? 'Ocultar Simulação' : 'Simular Notificação'}
          </button>
        </div>
        
        {/* Filtros */}
        <div className="flex space-x-2 mb-6 overflow-x-auto pb-2">
          <button
            onClick={() => setFiltroTipo('todos')}
            className={`px-3 py-1 rounded-md text-sm font-medium whitespace-nowrap ${
              filtroTipo === 'todos' 
                ? 'bg-indigo-100 text-indigo-800' 
                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
            }`}
          >
            Todos
          </button>
          <button
            onClick={() => setFiltroTipo('clima')}
            className={`px-3 py-1 rounded-md text-sm font-medium whitespace-nowrap ${
              filtroTipo === 'clima' 
                ? 'bg-blue-100 text-blue-800' 
                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
            }`}
          >
            <span className="material-symbols-outlined text-sm align-middle mr-1">cloud</span>
            Clima
          </button>
          <button
            onClick={() => setFiltroTipo('trabalho')}
            className={`px-3 py-1 rounded-md text-sm font-medium whitespace-nowrap ${
              filtroTipo === 'trabalho' 
                ? 'bg-purple-100 text-purple-800' 
                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
            }`}
          >
            <span className="material-symbols-outlined text-sm align-middle mr-1">work</span>
            Trabalho
          </button>
          <button
            onClick={() => setFiltroTipo('transporte')}
            className={`px-3 py-1 rounded-md text-sm font-medium whitespace-nowrap ${
              filtroTipo === 'transporte' 
                ? 'bg-amber-100 text-amber-800' 
                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
            }`}
          >
            <span className="material-symbols-outlined text-sm align-middle mr-1">directions_car</span>
            Transporte
          </button>
          <button
            onClick={() => setFiltroTipo('pessoal')}
            className={`px-3 py-1 rounded-md text-sm font-medium whitespace-nowrap ${
              filtroTipo === 'pessoal' 
                ? 'bg-green-100 text-green-800' 
                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
            }`}
          >
            <span className="material-symbols-outlined text-sm align-middle mr-1">person</span>
            Pessoal
          </button>
        </div>
        
        {/* Lista de lembretes */}
        <div className="space-y-4">
          {lembretesFiltrados.length > 0 ? (
            lembretesFiltrados.map((lembrete) => (
              <div 
                key={lembrete.id} 
                className={`p-4 border rounded-md ${getCorLembrete(lembrete.tipo)} ${
                  lembrete.lido ? 'opacity-70' : ''
                }`}
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-3">
                    <div className="h-10 w-10 rounded-full bg-white bg-opacity-50 flex items-center justify-center">
                      <span className="material-symbols-outlined">
                        {getIconeLembrete(lembrete.tipo)}
                      </span>
                    </div>
                  </div>
                  <div className="flex-grow">
                    <p className={`text-base ${lembrete.lido ? '' : 'font-medium'}`}>
                      {lembrete.texto}
                    </p>
                    <p className="text-sm mt-1 opacity-75">
                      {lembrete.horario}
                    </p>
                  </div>
                  <div className="ml-2 flex-shrink-0">
                    {!lembrete.lido && (
                      <button
                        onClick={() => marcarComoLido(lembrete.id)}
                        className="text-sm font-medium hover:underline"
                      >
                        Marcar como lido
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p className="text-gray-500 text-center py-8">Nenhum lembrete encontrado.</p>
          )}
        </div>
        
        {/* Simulação de notificação */}
        {mostrarSimulacao && (
          <div className="mt-8 border-t pt-6">
            <h2 className="text-lg font-medium text-gray-900 mb-4">Simulação de Notificações</h2>
            
            <div className="space-y-6">
              {/* Simulação de notificação push */}
              <div className="bg-gray-100 p-4 rounded-lg shadow-sm">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Notificação Push</h3>
                <div className="bg-white p-3 rounded-md shadow-sm border border-gray-200">
                  <div className="flex items-start">
                    <div className="h-10 w-10 rounded-md bg-indigo-100 flex items-center justify-center mr-3">
                      <span className="material-symbols-outlined text-indigo-600">notifications</span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">LifeHub</p>
                      <p className="text-sm text-gray-700">Está chovendo hoje, leve guarda-chuva</p>
                      <p className="text-xs text-gray-500 mt-1">Agora</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Simulação de WhatsApp */}
              <div className="bg-gray-100 p-4 rounded-lg shadow-sm">
                <h3 className="text-sm font-medium text-gray-700 mb-2">Notificação WhatsApp</h3>
                <div className="bg-white p-3 rounded-md shadow-sm border border-gray-200">
                  <div className="flex items-start">
                    <div className="h-10 w-10 rounded-md bg-green-500 flex items-center justify-center mr-3">
                      <span className="material-symbols-outlined text-white">chat</span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">LifeHub Assistente</p>
                      <p className="text-sm text-gray-700">
                        Olá! Lembrete: você tem uma reunião em 30 minutos. Os documentos já estão preparados na sua pasta de trabalho.
                      </p>
                      <p className="text-xs text-gray-500 mt-1">09:30</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-indigo-50 p-4 rounded-md">
                <p className="text-sm text-indigo-700 flex items-start">
                  <span className="material-symbols-outlined mr-2 flex-shrink-0">info</span>
                  <span>
                    Em uma versão real, você poderia configurar como deseja receber seus lembretes: push, WhatsApp, email ou SMS.
                  </span>
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
