'use client';

import { useState } from 'react';
import Link from 'next/link';
import { userData, tarefasData, climaData, eventosData, planoIAData } from '@/data/mockData';

export default function Dashboard() {
  const [planoGerado, setPlanoGerado] = useState(false);
  
  const proximaTarefa = tarefasData.find(tarefa => !tarefa.concluida);
  const proximoEvento = eventosData.find(evento => evento.data === '2025-05-19');
  
  const gerarPlanoDia = () => {
    setPlanoGerado(true);
  };
  
  const formatarHorario = (horario: string) => {
    return horario;
  };
  
  const obterSaudacao = () => {
    const hora = new Date().getHours();
    if (hora < 12) return 'Bom dia';
    if (hora < 18) return 'Boa tarde';
    return 'Boa noite';
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho com saudação */}
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{obterSaudacao()}, {userData.nome}!</h1>
            <p className="text-gray-600">Segunda-feira, 19 de maio de 2025</p>
          </div>
          <button
            onClick={gerarPlanoDia}
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-md transition duration-150 ease-in-out"
          >
            Ver meu plano do dia
          </button>
        </div>
      </div>

      {/* Resumo do dia */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Clima atual */}
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Clima Atual</h2>
            <Link href="/clima" className="text-indigo-600 hover:text-indigo-800 text-sm">Ver mais</Link>
          </div>
          <div className="flex items-center">
            <div className="flex-shrink-0 mr-4">
              <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="material-symbols-outlined text-3xl text-blue-500">
                  {climaData.atual.icone === 'partly-cloudy' ? 'partly_cloudy_day' : 
                   climaData.atual.icone === 'sunny' ? 'wb_sunny' : 'cloud'}
                </span>
              </div>
            </div>
            <div>
              <p className="text-3xl font-bold text-gray-900">{climaData.atual.temperatura}°C</p>
              <p className="text-gray-600 capitalize">{climaData.atual.condicao}</p>
            </div>
          </div>
          <p className="mt-4 text-sm text-gray-600">{climaData.mensagem}</p>
        </div>

        {/* Próxima tarefa */}
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Próxima Tarefa</h2>
            <Link href="/tarefas" className="text-indigo-600 hover:text-indigo-800 text-sm">Ver todas</Link>
          </div>
          {proximaTarefa ? (
            <div>
              <div className="flex items-center mb-2">
                <span className={`inline-block w-3 h-3 rounded-full mr-2 ${
                  proximaTarefa.prioridade === 'alta' ? 'bg-red-500' : 
                  proximaTarefa.prioridade === 'média' ? 'bg-yellow-500' : 'bg-green-500'
                }`}></span>
                <span className="text-sm text-gray-600 capitalize">{proximaTarefa.prioridade}</span>
              </div>
              <h3 className="text-xl font-medium text-gray-900">{proximaTarefa.titulo}</h3>
              <p className="text-gray-600 mt-1">Horário: {formatarHorario(proximaTarefa.horario)}</p>
              <div className="mt-4">
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 capitalize">
                  {proximaTarefa.categoria}
                </span>
              </div>
            </div>
          ) : (
            <p className="text-gray-600">Não há tarefas pendentes para hoje.</p>
          )}
        </div>

        {/* Próxima reunião */}
        <div className="bg-white shadow rounded-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Próximo Evento</h2>
            <Link href="/calendario" className="text-indigo-600 hover:text-indigo-800 text-sm">Ver agenda</Link>
          </div>
          {proximoEvento ? (
            <div>
              <h3 className="text-xl font-medium text-gray-900">{proximoEvento.titulo}</h3>
              <p className="text-gray-600 mt-1">
                {proximoEvento.inicio} - {proximoEvento.fim}
              </p>
              {proximoEvento.local && (
                <p className="text-gray-600 mt-1">
                  <span className="material-symbols-outlined text-sm align-middle mr-1">location_on</span>
                  {proximoEvento.local}
                </p>
              )}
              <div className="mt-4">
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 capitalize">
                  {proximoEvento.tipo}
                </span>
              </div>
            </div>
          ) : (
            <p className="text-gray-600">Não há eventos agendados para hoje.</p>
          )}
        </div>
      </div>

      {/* Plano do dia gerado pela IA */}
      {planoGerado && (
        <div className="bg-white shadow rounded-lg p-6 border-l-4 border-indigo-500">
          <div className="flex items-center mb-4">
            <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center mr-4">
              <span className="material-symbols-outlined text-indigo-600">smart_toy</span>
            </div>
            <div>
              <h2 className="text-lg font-semibold text-gray-900">Plano do Dia</h2>
              <p className="text-sm text-gray-600">Gerado por IA às {new Date().getHours()}:{String(new Date().getMinutes()).padStart(2, '0')}</p>
            </div>
          </div>
          
          <p className="text-gray-700 mb-4">{planoIAData.mensagem}</p>
          
          <div className="space-y-4">
            {planoIAData.plano.map((item, index) => (
              <div key={index} className="flex">
                <div className="flex-shrink-0 mr-4">
                  <div className="h-8 w-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-800 font-semibold">
                    {index + 1}
                  </div>
                </div>
                <div>
                  <p className="font-medium text-gray-900">{item.horario}</p>
                  <p className="text-gray-700">{item.atividade}</p>
                  <p className="text-sm text-gray-500">{item.contexto}</p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 bg-yellow-50 p-4 rounded-md">
            <h3 className="font-medium text-yellow-800 mb-2">Dicas para hoje:</h3>
            <ul className="space-y-1">
              {planoIAData.dicas.map((dica, index) => (
                <li key={index} className="flex items-start">
                  <span className="material-symbols-outlined text-yellow-600 mr-2">tips_and_updates</span>
                  <span className="text-sm text-yellow-700">{dica}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
