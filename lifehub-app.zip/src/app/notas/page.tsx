'use client';

import { useState } from 'react';
import { notasData } from '@/data/mockData';

export default function Notas() {
  const [notas, setNotas] = useState(notasData);
  const [filtroTag, setFiltroTag] = useState('todas');
  const [novaNota, setNovaNota] = useState('');
  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  
  // Obter todas as tags únicas
  const todasTags = Array.from(new Set(notas.flatMap(nota => nota.tags)));
  
  // Filtrar notas por tag
  const notasFiltradas = filtroTag === 'todas' 
    ? notas 
    : notas.filter(nota => nota.tags.includes(filtroTag));
  
  // Adicionar nova nota
  const adicionarNota = () => {
    if (!novaNota.trim()) return;
    
    const novaNota_ = {
      id: notas.length + 1,
      titulo: 'Nova nota',
      conteudo: novaNota,
      tags: ['Ideias'],
      data: '2025-05-19'
    };
    
    setNotas([novaNota_, ...notas]);
    setNovaNota('');
    setMostrarFormulario(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Notas Rápidas</h1>
          <button
            onClick={() => setMostrarFormulario(!mostrarFormulario)}
            className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <span className="material-symbols-outlined mr-1">add</span>
            Nova Nota
          </button>
        </div>
        
        {/* Formulário de nova nota */}
        {mostrarFormulario && (
          <div className="mb-6 p-4 border border-gray-200 rounded-md bg-gray-50">
            <h2 className="text-lg font-medium text-gray-900 mb-3">Captura Rápida</h2>
            <textarea
              value={novaNota}
              onChange={(e) => setNovaNota(e.target.value)}
              placeholder="Digite sua nota aqui..."
              className="w-full h-32 p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            ></textarea>
            <div className="flex justify-end mt-3 space-x-2">
              <button
                onClick={() => setMostrarFormulario(false)}
                className="px-3 py-1.5 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Cancelar
              </button>
              <button
                onClick={adicionarNota}
                className="px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Salvar
              </button>
            </div>
          </div>
        )}
        
        {/* Filtros de tags */}
        <div className="flex space-x-2 mb-6 overflow-x-auto pb-2">
          <button
            onClick={() => setFiltroTag('todas')}
            className={`px-3 py-1 rounded-md text-sm font-medium whitespace-nowrap ${
              filtroTag === 'todas' 
                ? 'bg-indigo-100 text-indigo-800' 
                : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
            }`}
          >
            Todas
          </button>
          {todasTags.map((tag) => (
            <button
              key={tag}
              onClick={() => setFiltroTag(tag)}
              className={`px-3 py-1 rounded-md text-sm font-medium whitespace-nowrap ${
                filtroTag === tag 
                  ? 'bg-indigo-100 text-indigo-800' 
                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
        
        {/* Lista de notas */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {notasFiltradas.length > 0 ? (
            notasFiltradas.map((nota) => (
              <div 
                key={nota.id} 
                className="p-4 border border-gray-200 rounded-md hover:shadow-md transition-shadow"
              >
                <h3 className="font-medium text-gray-900">{nota.titulo}</h3>
                <p className="text-sm text-gray-600 mt-2 line-clamp-3">{nota.conteudo}</p>
                <div className="flex justify-between items-center mt-4">
                  <div className="flex flex-wrap gap-1">
                    {nota.tags.map((tag, index) => (
                      <span 
                        key={index}
                        className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <span className="text-xs text-gray-500">{nota.data}</span>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-2 text-gray-500 text-center py-8">
              Nenhuma nota encontrada.
            </div>
          )}
        </div>
        
        {/* Widget de captura rápida fixo */}
        <div className="fixed bottom-6 right-6 md:bottom-8 md:right-8 z-10">
          <button
            onClick={() => setMostrarFormulario(true)}
            className="h-14 w-14 rounded-full bg-indigo-600 text-white shadow-lg flex items-center justify-center hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <span className="material-symbols-outlined text-2xl">edit</span>
          </button>
        </div>
      </div>
    </div>
  );
}
