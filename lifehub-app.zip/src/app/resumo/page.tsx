'use client';

import { resumoDiarioData } from '@/data/mockData';

export default function Resumo() {
  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex items-center mb-6">
          <div className="h-12 w-12 rounded-full bg-indigo-100 flex items-center justify-center mr-4">
            <span className="material-symbols-outlined text-2xl text-indigo-600">smart_toy</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Resumo Diário com IA</h1>
            <p className="text-gray-600">{resumoDiarioData.data}</p>
          </div>
        </div>
        
        {/* Conquistas do dia */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
            <span className="material-symbols-outlined text-green-500 mr-2">emoji_events</span>
            Conquistas do Dia
          </h2>
          <div className="bg-green-50 rounded-lg p-4">
            <ul className="space-y-2">
              {resumoDiarioData.conquistas.map((conquista, index) => (
                <li key={index} className="flex items-start">
                  <span className="material-symbols-outlined text-green-600 mr-2 flex-shrink-0">check_circle</span>
                  <span className="text-green-800">{conquista}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        {/* Pendências */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
            <span className="material-symbols-outlined text-amber-500 mr-2">pending_actions</span>
            Pendências
          </h2>
          <div className="bg-amber-50 rounded-lg p-4">
            <ul className="space-y-2">
              {resumoDiarioData.pendencias.map((pendencia, index) => (
                <li key={index} className="flex items-start">
                  <span className="material-symbols-outlined text-amber-600 mr-2 flex-shrink-0">schedule</span>
                  <span className="text-amber-800">{pendencia}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        {/* Sugestões para amanhã */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
            <span className="material-symbols-outlined text-blue-500 mr-2">tips_and_updates</span>
            Sugestões para Amanhã
          </h2>
          <div className="bg-blue-50 rounded-lg p-4">
            <ul className="space-y-2">
              {resumoDiarioData.sugestoes.map((sugestao, index) => (
                <li key={index} className="flex items-start">
                  <span className="material-symbols-outlined text-blue-600 mr-2 flex-shrink-0">lightbulb</span>
                  <span className="text-blue-800">{sugestao}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        {/* Análise da IA */}
        <div className="border-t pt-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Análise Personalizada</h2>
          <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-md">
            <div className="flex">
              <span className="material-symbols-outlined text-indigo-600 mr-3 flex-shrink-0">psychology</span>
              <p className="text-indigo-800">{resumoDiarioData.analiseIA}</p>
            </div>
          </div>
        </div>
        
        {/* Botões de ação */}
        <div className="mt-8 flex flex-col sm:flex-row sm:justify-end space-y-3 sm:space-y-0 sm:space-x-3">
          <button className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
            <span className="material-symbols-outlined mr-2">download</span>
            Exportar Resumo
          </button>
          <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
            <span className="material-symbols-outlined mr-2">calendar_today</span>
            Planejar Amanhã
          </button>
        </div>
      </div>
      
      {/* Gráfico de produtividade semanal */}
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Produtividade Semanal</h2>
        <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg border border-gray-200">
          <div className="w-full px-6">
            <div className="flex justify-between mb-2">
              <span className="text-xs text-gray-500">Seg</span>
              <span className="text-xs text-gray-500">Ter</span>
              <span className="text-xs text-gray-500">Qua</span>
              <span className="text-xs text-gray-500">Qui</span>
              <span className="text-xs text-gray-500">Sex</span>
              <span className="text-xs text-gray-500">Sáb</span>
              <span className="text-xs text-gray-500">Dom</span>
            </div>
            <div className="flex items-end justify-between h-40">
              <div className="w-8 bg-indigo-500 rounded-t-md" style={{ height: '75%' }}></div>
              <div className="w-8 bg-indigo-500 rounded-t-md" style={{ height: '60%' }}></div>
              <div className="w-8 bg-indigo-500 rounded-t-md" style={{ height: '85%' }}></div>
              <div className="w-8 bg-indigo-500 rounded-t-md" style={{ height: '50%' }}></div>
              <div className="w-8 bg-indigo-500 rounded-t-md" style={{ height: '70%' }}></div>
              <div className="w-8 bg-indigo-300 rounded-t-md" style={{ height: '30%' }}></div>
              <div className="w-8 bg-indigo-300 rounded-t-md" style={{ height: '20%' }}></div>
            </div>
            <div className="flex justify-between mt-2">
              <span className="text-xs text-gray-500">75%</span>
              <span className="text-xs text-gray-500">60%</span>
              <span className="text-xs text-gray-500">85%</span>
              <span className="text-xs text-gray-500">50%</span>
              <span className="text-xs text-gray-500">70%</span>
              <span className="text-xs text-gray-500">30%</span>
              <span className="text-xs text-gray-500">20%</span>
            </div>
          </div>
        </div>
        <p className="text-sm text-gray-500 mt-4 text-center">
          Sua produtividade média esta semana: <span className="font-medium text-indigo-600">68%</span>
        </p>
      </div>
    </div>
  );
}
